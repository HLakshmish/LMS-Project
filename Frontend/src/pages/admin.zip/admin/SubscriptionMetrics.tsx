import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MainLayout from '../../components/layout/MainLayout';
import AdminSidebar from '../../components/layout/AdminSidebar';
import Card from '../../components/ui/Card';

interface DashboardPageProps {
  user: {
    name: string;
    role: string;
    avatar?: string;
  };
  onLogout: () => void;
}

interface SubscriptionMetricsData {
  totalRevenue: number;
  activeSubscriptions: number;
  averageSubscriptionLength: number;
  churnRate: number;
  subscriptionsByPlan: {
    planName: string;
    count: number;
    revenue: number;
  }[];
  revenueByMonth: {
    month: string;
    amount: number;
  }[];
  subscriptionTrends: {
    month: string;
    newSubscriptions: number;
    canceledSubscriptions: number;
  }[];
}

const SubscriptionMetrics: React.FC<DashboardPageProps> = ({ user, onLogout }) => {
  const [metrics, setMetrics] = useState<SubscriptionMetricsData>({
    totalRevenue: 0,
    activeSubscriptions: 0,
    averageSubscriptionLength: 0,
    churnRate: 0,
    subscriptionsByPlan: [],
    revenueByMonth: [],
    subscriptionTrends: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
  };

  useEffect(() => {
    const fetchSubscriptionMetrics = async () => {
      try {
        setLoading(true);
        const response = await axios.get('http://localhost:8000/api/subscriptions/metrics/', getAuthHeaders());
        setMetrics(response.data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch subscription metrics');
        console.error('Error fetching subscription metrics:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSubscriptionMetrics();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <MainLayout user={user} onLogout={onLogout} sidebarContent={<AdminSidebar />}>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Subscription Metrics</h1>
            <p className="mt-2 text-sm text-gray-600">
              Track subscription performance and revenue analytics
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          {/* Key Metrics */}
          <div className="grid grid-cols-1 gap-6 mb-8 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-green-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Total Revenue</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : formatCurrency(metrics.totalRevenue)}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-blue-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Active Subscriptions</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : metrics.activeSubscriptions}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-purple-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Avg. Subscription Length</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : `${metrics.averageSubscriptionLength} months`}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-red-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Churn Rate</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : `${metrics.churnRate}%`}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Subscription Plans and Revenue Charts */}
          <div className="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-2">
            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">
                  Revenue by Subscription Plan
                </h3>
                <div className="space-y-6">
                  {!loading && metrics.subscriptionsByPlan.map((plan, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <span className="text-sm font-medium text-gray-900">{plan.planName}</span>
                          <span className="ml-2 px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                            {((plan.count / metrics.activeSubscriptions) * 100).toFixed(1)}% of total
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="block text-sm font-semibold text-gray-900">
                            {formatCurrency(plan.revenue)}
                          </span>
                          <span className="block text-xs text-gray-500">
                            {plan.count} active subscriptions
                          </span>
                        </div>
                      </div>
                      <div className="relative">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{
                              width: `${(plan.revenue / metrics.totalRevenue) * 100}%`
                            }}
                          />
                        </div>
                        <div className="mt-1 flex justify-between text-xs text-gray-500">
                          <span>Revenue Share</span>
                          <span>{((plan.revenue / metrics.totalRevenue) * 100).toFixed(1)}%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-600">
                          Avg. Revenue per Subscription:
                        </span>
                        <span className="font-medium text-gray-900">
                          {formatCurrency(plan.revenue / plan.count)}
                        </span>
                      </div>
                      {index < metrics.subscriptionsByPlan.length - 1 && (
                        <div className="border-b border-gray-200 pt-4"></div>
                      )}
                    </div>
                  ))}
                  {!loading && metrics.subscriptionsByPlan.length === 0 && (
                    <div className="text-center text-gray-500 py-4">
                      No subscription plans data available
                    </div>
                  )}
                </div>
              </div>
            </Card>

            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">
                  Monthly Revenue Trend
                </h3>
                <div className="h-80">
                  {!loading && metrics.revenueByMonth.length > 0 && (
                    <div className="relative h-full">
                      <div className="absolute inset-0 flex items-end justify-between">
                        {metrics.revenueByMonth.map((data, index) => (
                          <div
                            key={index}
                            className="relative flex flex-col items-center group"
                            style={{ width: `${100 / metrics.revenueByMonth.length}%` }}
                          >
                            {/* Tooltip */}
                            <div className="absolute bottom-full mb-2 hidden group-hover:block w-32 bg-gray-900 text-white text-xs rounded py-1 px-2 text-center">
                              <p className="font-medium">{formatCurrency(data.amount)}</p>
                              <p className="text-gray-300">{data.month}</p>
                              {index > 0 && (
                                <p className={`text-xs ${
                                  data.amount > metrics.revenueByMonth[index - 1].amount
                                    ? 'text-green-400'
                                    : 'text-red-400'
                                }`}>
                                  {((data.amount - metrics.revenueByMonth[index - 1].amount) / metrics.revenueByMonth[index - 1].amount * 100).toFixed(1)}% vs prev month
                                </p>
                              )}
                            </div>
                            {/* Bar */}
                            <div
                              className="w-full bg-gradient-to-t from-green-500 to-green-400 rounded-t transition-all duration-300 ease-in-out hover:opacity-80"
                              style={{
                                height: `${(data.amount / Math.max(...metrics.revenueByMonth.map(d => d.amount))) * 100}%`
                              }}
                            />
                            {/* Month Label */}
                            <span className="text-xs text-gray-600 mt-2 transform -rotate-45 origin-top-left">
                              {data.month}
                            </span>
                          </div>
                        ))}
                      </div>
                      {/* Y-axis labels */}
                      <div className="absolute left-0 top-0 bottom-8 w-12 flex flex-col justify-between">
                        {[...Array(5)].map((_, i) => (
                          <div key={i} className="text-xs text-gray-500 -translate-x-2">
                            {formatCurrency((Math.max(...metrics.revenueByMonth.map(d => d.amount)) * (4 - i) / 4))}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {!loading && metrics.revenueByMonth.length === 0 && (
                    <div className="flex items-center justify-center h-full text-gray-500">
                      No revenue data available
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </div>

          {/* Subscription Trends */}
          <Card className="bg-white mb-8">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">
                  Subscription Trends
                </h3>
                <div className="flex space-x-4">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-600">New Subscriptions</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-600">Canceled Subscriptions</span>
                  </div>
                </div>
              </div>
              
              <div className="h-80">
                {!loading && metrics.subscriptionTrends.length > 0 && (
                  <div className="relative h-full">
                    <div className="absolute inset-0 flex items-end justify-between">
                      {metrics.subscriptionTrends.map((data, index) => (
                        <div
                          key={index}
                          className="relative flex flex-col items-center group"
                          style={{ width: `${100 / metrics.subscriptionTrends.length}%` }}
                        >
                          {/* Tooltip */}
                          <div className="absolute bottom-full mb-2 hidden group-hover:block w-48 bg-gray-900 text-white text-xs rounded py-2 px-3">
                            <p className="font-medium mb-1">{data.month}</p>
                            <div className="space-y-1">
                              <p className="flex justify-between">
                                <span>New:</span>
                                <span className="text-blue-400">{data.newSubscriptions}</span>
                              </p>
                              <p className="flex justify-between">
                                <span>Canceled:</span>
                                <span className="text-red-400">{data.canceledSubscriptions}</span>
                              </p>
                              <p className="flex justify-between border-t border-gray-700 pt-1">
                                <span>Net Change:</span>
                                <span className={data.newSubscriptions - data.canceledSubscriptions >= 0 ? 'text-green-400' : 'text-red-400'}>
                                  {data.newSubscriptions - data.canceledSubscriptions}
                                </span>
                              </p>
                            </div>
                          </div>
                          
                          {/* Bars */}
                          <div className="relative w-full flex justify-center space-x-1">
                            <div
                              className="w-1/3 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t transition-all duration-300 ease-in-out hover:opacity-80"
                              style={{
                                height: `${(data.newSubscriptions / Math.max(...metrics.subscriptionTrends.map(d => Math.max(d.newSubscriptions, d.canceledSubscriptions)))) * 100}%`
                              }}
                            />
                            <div
                              className="w-1/3 bg-gradient-to-t from-red-600 to-red-400 rounded-t transition-all duration-300 ease-in-out hover:opacity-80"
                              style={{
                                height: `${(data.canceledSubscriptions / Math.max(...metrics.subscriptionTrends.map(d => Math.max(d.newSubscriptions, d.canceledSubscriptions)))) * 100}%`
                              }}
                            />
                          </div>
                          
                          {/* Month Label */}
                          <span className="text-xs text-gray-600 mt-2 transform -rotate-45 origin-top-left">
                            {data.month}
                          </span>
                        </div>
                      ))}
                    </div>
                    
                    {/* Y-axis labels */}
                    <div className="absolute left-0 top-0 bottom-8 w-12 flex flex-col justify-between">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="text-xs text-gray-500 -translate-x-2">
                          {Math.round(Math.max(...metrics.subscriptionTrends.map(d => Math.max(d.newSubscriptions, d.canceledSubscriptions))) * (4 - i) / 4)}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {!loading && metrics.subscriptionTrends.length === 0 && (
                  <div className="flex items-center justify-center h-full text-gray-500">
                    No subscription trends data available
                  </div>
                )}
              </div>
              
              {/* Summary Statistics */}
              {!loading && metrics.subscriptionTrends.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 pt-6 border-t border-gray-200">
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-blue-800 mb-2">Average New Subscriptions</h4>
                    <p className="text-2xl font-semibold text-blue-900">
                      {(metrics.subscriptionTrends.reduce((acc, curr) => acc + curr.newSubscriptions, 0) / metrics.subscriptionTrends.length).toFixed(1)}
                    </p>
                    <p className="text-sm text-blue-600">per month</p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-red-800 mb-2">Average Cancellations</h4>
                    <p className="text-2xl font-semibold text-red-900">
                      {(metrics.subscriptionTrends.reduce((acc, curr) => acc + curr.canceledSubscriptions, 0) / metrics.subscriptionTrends.length).toFixed(1)}
                    </p>
                    <p className="text-sm text-red-600">per month</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-gray-800 mb-2">Net Growth Rate</h4>
                    <p className="text-2xl font-semibold text-gray-900">
                      {((metrics.subscriptionTrends.reduce((acc, curr) => acc + curr.newSubscriptions - curr.canceledSubscriptions, 0) / metrics.subscriptionTrends.length) * 100 / metrics.activeSubscriptions).toFixed(1)}%
                    </p>
                    <p className="text-sm text-gray-600">monthly average</p>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default SubscriptionMetrics; 