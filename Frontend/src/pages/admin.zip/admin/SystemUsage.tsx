import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MainLayout, AdminSidebar } from '../../components/layout';
import Card from '../../components/ui/Card';

interface DashboardPageProps {
  user: {
    name: string;
    role: string;
    avatar?: string;
  };
  onLogout: () => void;
}

interface SystemMetrics {
  serverStatus: {
    status: 'operational' | 'degraded' | 'down';
    uptime: number;
    lastRestart: string;
    cpuUsage: number;
    memoryUsage: number;
    diskUsage: number;
  };
  databaseMetrics: {
    status: 'operational' | 'degraded' | 'down';
    connectionCount: number;
    queryResponseTime: number;
    activeTransactions: number;
    storageUsage: number;
  };
  userActivity: {
    currentActiveUsers: number;
    peakConcurrentUsers: number;
    averageSessionDuration: number;
    totalRequestsToday: number;
  };
  performanceMetrics: {
    averageResponseTime: number;
    errorRate: number;
    requestsPerMinute: number;
    bandwidthUsage: number;
  };
  activityLog: {
    timestamp: string;
    type: 'info' | 'warning' | 'error';
    message: string;
    details?: string;
  }[];
  resourceUtilization: {
    time: string;
    cpu: number;
    memory: number;
    network: number;
  }[];
}

const SystemUsage: React.FC<DashboardPageProps> = ({ user, onLogout }) => {
  const [metrics, setMetrics] = useState<SystemMetrics>({
    serverStatus: {
      status: 'operational',
      uptime: 0,
      lastRestart: '',
      cpuUsage: 0,
      memoryUsage: 0,
      diskUsage: 0
    },
    databaseMetrics: {
      status: 'operational',
      connectionCount: 0,
      queryResponseTime: 0,
      activeTransactions: 0,
      storageUsage: 0
    },
    userActivity: {
      currentActiveUsers: 0,
      peakConcurrentUsers: 0,
      averageSessionDuration: 0,
      totalRequestsToday: 0
    },
    performanceMetrics: {
      averageResponseTime: 0,
      errorRate: 0,
      requestsPerMinute: 0,
      bandwidthUsage: 0
    },
    activityLog: [],
    resourceUtilization: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
  };

  useEffect(() => {
    const fetchSystemMetrics = async () => {
      try {
        setLoading(true);
        const response = await axios.get('http://localhost:8000/api/system/metrics/', getAuthHeaders());
        setMetrics(response.data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch system metrics');
        console.error('Error fetching system metrics:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSystemMetrics();
    // Refresh data every minute
    const interval = setInterval(fetchSystemMetrics, 60000);
    return () => clearInterval(interval);
  }, []);

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / (24 * 60 * 60));
    const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
    const minutes = Math.floor((seconds % (60 * 60)) / 60);
    return `${days}d ${hours}h ${minutes}m`;
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };

  const getStatusColor = (status: 'operational' | 'degraded' | 'down') => {
    switch (status) {
      case 'operational':
        return 'bg-green-100 text-green-800';
      case 'degraded':
        return 'bg-yellow-100 text-yellow-800';
      case 'down':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <MainLayout user={user} onLogout={onLogout} sidebarContent={<AdminSidebar />}>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">System Usage</h1>
            <p className="mt-2 text-sm text-gray-600">
              Monitor system performance, resource utilization, and user activity
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          {/* System Status Overview */}
          <div className="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-2">
            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Server Status</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Status</span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(metrics.serverStatus.status)}`}>
                      {metrics.serverStatus.status.charAt(0).toUpperCase() + metrics.serverStatus.status.slice(1)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Uptime</span>
                    <span className="text-sm text-gray-900">{formatUptime(metrics.serverStatus.uptime)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Last Restart</span>
                    <span className="text-sm text-gray-900">{new Date(metrics.serverStatus.lastRestart).toLocaleString()}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">CPU Usage</span>
                      <span className="text-sm text-gray-900">{metrics.serverStatus.cpuUsage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          metrics.serverStatus.cpuUsage > 90 ? 'bg-red-600' :
                          metrics.serverStatus.cpuUsage > 70 ? 'bg-yellow-600' :
                          'bg-green-600'
                        }`}
                        style={{ width: `${metrics.serverStatus.cpuUsage}%` }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Memory Usage</span>
                      <span className="text-sm text-gray-900">{metrics.serverStatus.memoryUsage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          metrics.serverStatus.memoryUsage > 90 ? 'bg-red-600' :
                          metrics.serverStatus.memoryUsage > 70 ? 'bg-yellow-600' :
                          'bg-green-600'
                        }`}
                        style={{ width: `${metrics.serverStatus.memoryUsage}%` }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Disk Usage</span>
                      <span className="text-sm text-gray-900">{metrics.serverStatus.diskUsage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          metrics.serverStatus.diskUsage > 90 ? 'bg-red-600' :
                          metrics.serverStatus.diskUsage > 70 ? 'bg-yellow-600' :
                          'bg-green-600'
                        }`}
                        style={{ width: `${metrics.serverStatus.diskUsage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Database Metrics</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Status</span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(metrics.databaseMetrics.status)}`}>
                      {metrics.databaseMetrics.status.charAt(0).toUpperCase() + metrics.databaseMetrics.status.slice(1)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Active Connections</span>
                    <span className="text-sm text-gray-900">{metrics.databaseMetrics.connectionCount}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Query Response Time</span>
                    <span className="text-sm text-gray-900">{metrics.databaseMetrics.queryResponseTime}ms</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Active Transactions</span>
                    <span className="text-sm text-gray-900">{metrics.databaseMetrics.activeTransactions}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Storage Usage</span>
                      <span className="text-sm text-gray-900">{metrics.databaseMetrics.storageUsage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          metrics.databaseMetrics.storageUsage > 90 ? 'bg-red-600' :
                          metrics.databaseMetrics.storageUsage > 70 ? 'bg-yellow-600' :
                          'bg-green-600'
                        }`}
                        style={{ width: `${metrics.databaseMetrics.storageUsage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* User Activity and Performance */}
          <div className="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-2">
            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">User Activity</h3>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 rounded-lg p-4">
                      <div className="text-sm font-medium text-blue-800 mb-1">Active Users</div>
                      <div className="text-2xl font-semibold text-blue-900">
                        {metrics.userActivity.currentActiveUsers}
                      </div>
                      <div className="text-sm text-blue-600">Current</div>
                    </div>
                    <div className="bg-green-50 rounded-lg p-4">
                      <div className="text-sm font-medium text-green-800 mb-1">Peak Users</div>
                      <div className="text-2xl font-semibold text-green-900">
                        {metrics.userActivity.peakConcurrentUsers}
                      </div>
                      <div className="text-sm text-green-600">Today</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-500">Average Session Duration</span>
                      <span className="text-sm text-gray-900">
                        {Math.floor(metrics.userActivity.averageSessionDuration / 60)}m {metrics.userActivity.averageSessionDuration % 60}s
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Total Requests Today</span>
                      <span className="text-sm text-gray-900">{metrics.userActivity.totalRequestsToday.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Performance Metrics</h3>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-purple-50 rounded-lg p-4">
                      <div className="text-sm font-medium text-purple-800 mb-1">Response Time</div>
                      <div className="text-2xl font-semibold text-purple-900">
                        {metrics.performanceMetrics.averageResponseTime}ms
                      </div>
                      <div className="text-sm text-purple-600">Average</div>
                    </div>
                    <div className="bg-red-50 rounded-lg p-4">
                      <div className="text-sm font-medium text-red-800 mb-1">Error Rate</div>
                      <div className="text-2xl font-semibold text-red-900">
                        {metrics.performanceMetrics.errorRate}%
                      </div>
                      <div className="text-sm text-red-600">Last hour</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-500">Requests per Minute</span>
                      <span className="text-sm text-gray-900">{metrics.performanceMetrics.requestsPerMinute}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-500">Bandwidth Usage</span>
                      <span className="text-sm text-gray-900">{formatBytes(metrics.performanceMetrics.bandwidthUsage)}/s</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Resource Utilization Chart */}
          <Card className="bg-white mb-8">
            <div className="p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Resource Utilization</h3>
              <div className="h-80">
                {!loading && metrics.resourceUtilization.length > 0 && (
                  <div className="relative h-full">
                    <div className="absolute inset-0 flex items-end justify-between">
                      {metrics.resourceUtilization.map((data, index) => (
                        <div
                          key={index}
                          className="relative flex flex-col items-center group"
                          style={{ width: `${100 / metrics.resourceUtilization.length}%` }}
                        >
                          {/* Tooltip */}
                          <div className="absolute bottom-full mb-2 hidden group-hover:block w-48 bg-gray-900 text-white text-xs rounded py-2 px-3">
                            <p className="font-medium mb-1">{data.time}</p>
                            <div className="space-y-1">
                              <p className="flex justify-between">
                                <span>CPU:</span>
                                <span className="text-blue-400">{data.cpu}%</span>
                              </p>
                              <p className="flex justify-between">
                                <span>Memory:</span>
                                <span className="text-green-400">{data.memory}%</span>
                              </p>
                              <p className="flex justify-between">
                                <span>Network:</span>
                                <span className="text-purple-400">{formatBytes(data.network)}/s</span>
                              </p>
                            </div>
                          </div>

                          {/* Stacked Bars */}
                          <div className="relative w-full flex justify-center">
                            <div className="w-4/5 flex flex-col space-y-1">
                              <div
                                className="w-full bg-blue-500 rounded-t transition-all duration-300 ease-in-out hover:opacity-80"
                                style={{ height: `${data.cpu}%` }}
                              />
                              <div
                                className="w-full bg-green-500 transition-all duration-300 ease-in-out hover:opacity-80"
                                style={{ height: `${data.memory}%` }}
                              />
                              <div
                                className="w-full bg-purple-500 rounded-b transition-all duration-300 ease-in-out hover:opacity-80"
                                style={{ height: `${(data.network / 1e6) * 100}%` }}
                              />
                            </div>
                          </div>

                          {/* Time Label */}
                          <span className="text-xs text-gray-600 mt-2 transform -rotate-45 origin-top-left">
                            {new Date(data.time).toLocaleTimeString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <div className="mt-4 flex justify-center space-x-8">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">CPU Usage</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Memory Usage</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Network Usage</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Activity Log */}
          <Card className="bg-white">
            <div className="p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Activity Log</h3>
              <div className="space-y-4">
                {metrics.activityLog.map((log, index) => (
                  <div key={index} className="flex space-x-3">
                    <div className={`flex-shrink-0 w-2 h-2 mt-2 rounded-full ${
                      log.type === 'error' ? 'bg-red-500' :
                      log.type === 'warning' ? 'bg-yellow-500' :
                      'bg-blue-500'
                    }`} />
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-gray-900">{log.message}</p>
                        <span className="text-xs text-gray-500">{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                      {log.details && (
                        <p className="text-sm text-gray-500">{log.details}</p>
                      )}
                    </div>
                  </div>
                ))}
                {metrics.activityLog.length === 0 && (
                  <div className="text-center text-gray-500 py-4">
                    No activity logs available
                  </div>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
};

export default SystemUsage; 