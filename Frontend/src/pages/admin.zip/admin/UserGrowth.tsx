import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MainLayout, AdminSidebar } from '../../components/layout';
import Card from '../../components/ui/Card';

interface DashboardPageProps {
  user: {
    name: string;
    role: string;
    avatar?: string;
  };
  onLogout: () => void;
}

interface UserGrowthStats {
  totalUsers: number;
  newUsersThisMonth: number;
  growthRate: number;
  usersByRole: {
    students: number;
    teachers: number;
    admins: number;
  };
  monthlyGrowth: {
    month: string;
    count: number;
  }[];
}

const UserGrowth: React.FC<DashboardPageProps> = ({ user, onLogout }) => {
  const [stats, setStats] = useState<UserGrowthStats>({
    totalUsers: 0,
    newUsersThisMonth: 0,
    growthRate: 0,
    usersByRole: {
      students: 0,
      teachers: 0,
      admins: 0
    },
    monthlyGrowth: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
  };

  useEffect(() => {
    const fetchUserGrowthStats = async () => {
      try {
        setLoading(true);
        const response = await axios.get('http://localhost:8000/api/users/growth-stats/', getAuthHeaders());
        setStats(response.data);
        setError(null);
      } catch (err) {
        setError('Failed to fetch user growth statistics');
        console.error('Error fetching user growth stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchUserGrowthStats();
  }, []);

  return (
    <MainLayout user={user} onLogout={onLogout} sidebarContent={<AdminSidebar />}>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">User Growth Analytics</h1>
            <p className="mt-2 text-sm text-gray-600">
              Track user growth and engagement metrics across your platform
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          {/* Key Metrics */}
          <div className="grid grid-cols-1 gap-6 mb-8 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-blue-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Total Users</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : (stats.usersByRole.students + stats.usersByRole.teachers + stats.usersByRole.admins)}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-green-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">New Users This Month</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : stats.newUsersThisMonth}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-white overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0 rounded-md bg-purple-500 p-3">
                    <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Growth Rate</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">
                          {loading ? '-' : `${stats.growthRate}%`}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* User Distribution by Role */}
          <div className="grid grid-cols-1 gap-6 mb-8 lg:grid-cols-2">
            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">
                  User Distribution by Role
                </h3>
                <div className="space-y-4">
                  {!loading && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-600">Students</span>
                          <span className="text-sm text-gray-900">{stats.usersByRole.students}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{
                              width: `${(stats.usersByRole.students / stats.totalUsers) * 100}%`
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-600">Teachers</span>
                          <span className="text-sm text-gray-900">{stats.usersByRole.teachers}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-600 h-2 rounded-full"
                            style={{
                              width: `${(stats.usersByRole.teachers / stats.totalUsers) * 100}%`
                            }}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-600">Admins</span>
                          <span className="text-sm text-gray-900">{stats.usersByRole.admins}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full"
                            style={{
                              width: `${(stats.usersByRole.admins / stats.totalUsers) * 100}%`
                            }}
                          />
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </Card>

            {/* Monthly Growth Chart */}
            <Card className="bg-white">
              <div className="p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">
                  Monthly User Growth
                </h3>
                <div className="h-64">
                  {!loading && stats.monthlyGrowth.length > 0 && (
                    <div className="relative h-full">
                      <div className="absolute bottom-0 left-0 right-0 flex items-end justify-between h-full">
                        {stats.monthlyGrowth.map((data, index) => (
                          <div
                            key={index}
                            className="flex flex-col items-center w-full"
                          >
                            <div
                              className="w-full bg-blue-500 rounded-t"
                              style={{
                                height: `${(data.count / Math.max(...stats.monthlyGrowth.map(d => d.count))) * 100}%`
                              }}
                            />
                            <span className="text-xs text-gray-600 mt-2">{data.month}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default UserGrowth; 