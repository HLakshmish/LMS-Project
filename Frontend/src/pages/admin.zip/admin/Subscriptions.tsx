import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MainLayout, AdminSidebar } from '../../components/layout';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';

interface DashboardPageProps {
  user: {
    name: string;
    role: string;
    avatar?: string;
    [key: string]: any;
  };
  onLogout: () => void;
}

interface Subscription {
  id?: number;
  name: string;
  description: string;
  duration_days: number;
  price: number;
  max_exams: number;
  features: string;
  is_active: boolean;
  created_at?: string;
  updated_at?: string | null;
}

const initialFormState: Subscription = {
  name: '',
  description: '',
  duration_days: 30,
  price: 0,
  max_exams: 0,
  features: '',
  is_active: true,
};

const Subscriptions: React.FC<DashboardPageProps> = ({ user, onLogout }) => {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [formData, setFormData] = useState<Subscription>(initialFormState);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
  };

  const fetchSubscriptions = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:8000/api/subscriptions/subscriptions/', getAuthHeaders());
      setSubscriptions(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to fetch subscriptions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? Number(value) : value,
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: checked,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      if (isEditing && formData.id) {
        await axios.put(
          `http://localhost:8000/api/subscriptions/subscriptions/${formData.id}/`,
          formData,
          getAuthHeaders()
        );
      } else {
        await axios.post(
          'http://localhost:8000/api/subscriptions/subscriptions/',
          formData,
          getAuthHeaders()
        );
      }
      setFormData(initialFormState);
      setIsEditing(false);
      fetchSubscriptions();
      setError(null);
    } catch (err) {
      setError('Failed to save subscription');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (subscription: Subscription) => {
    setFormData(subscription);
    setIsEditing(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this subscription?')) {
      try {
        setLoading(true);
        await axios.delete(
          `http://localhost:8000/api/subscriptions/subscriptions/${id}/`,
          getAuthHeaders()
        );
        fetchSubscriptions();
        setError(null);
      } catch (err) {
        setError('Failed to delete subscription');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <MainLayout user={user} onLogout={onLogout} sidebarContent={<AdminSidebar />}>
      <div className="h-screen bg-gray-50 overflow-hidden flex flex-col">
        {/* Header Section */}
        <div className="bg-blue-600 text-white py-6 px-8 flex-none">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-2xl font-bold mb-2">Subscription Plans</h1>
            <p className="text-blue-100">Manage your subscription plans and pricing</p>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-auto px-8 py-6">
          <div className="max-w-7xl mx-auto">
            {/* Action Button */}
            <div className="mb-6 flex justify-end">
              <Button
                type="button"
                onClick={() => {
                  setFormData(initialFormState);
                  setIsEditing(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200"
              >
                <svg className="-ml-1 mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                </svg>
                Create New Plan
              </Button>
            </div>

            {error && (
              <div className="mb-6 p-4 rounded-md bg-red-50 border-l-4 border-red-500">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-base font-medium text-red-800">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Form Card */}
            <Card className="mb-8 shadow-lg rounded-lg overflow-hidden bg-white">
              <div className="bg-blue-600 px-6 py-4 text-white">
                <h2 className="text-xl font-semibold">
                  {isEditing ? 'Edit Subscription Plan' : 'Create New Subscription Plan'}
                </h2>
              </div>
              <div className="p-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">Plan Name</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base transition-all duration-200"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">Description</label>
                      <textarea
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        rows={3}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base transition-all duration-200"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">Duration (days)</label>
                      <input
                        type="number"
                        name="duration_days"
                        value={formData.duration_days}
                        onChange={handleInputChange}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base transition-all duration-200"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">Price ($)</label>
                      <div className="relative rounded-lg shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-gray-500 text-base">$</span>
                        </div>
                        <input
                          type="number"
                          name="price"
                          value={formData.price}
                          onChange={handleInputChange}
                          className="w-full rounded-lg border-gray-300 pl-7 focus:ring-blue-500 focus:border-blue-500 text-base transition-all duration-200"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">Max Exams</label>
                      <input
                        type="number"
                        name="max_exams"
                        value={formData.max_exams}
                        onChange={handleInputChange}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base transition-all duration-200"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-base font-medium text-gray-700 mb-1">Features</label>
                      <input
                        type="text"
                        name="features"
                        value={formData.features}
                        onChange={handleInputChange}
                        className="w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 text-base transition-all duration-200"
                        placeholder="Comma-separated list of features"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex items-center mt-4">
                    <input
                      type="checkbox"
                      name="is_active"
                      checked={formData.is_active}
                      onChange={handleCheckboxChange}
                      className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded transition-colors duration-200"
                    />
                    <label className="ml-2 block text-base text-gray-900">Active</label>
                  </div>

                  <div className="flex justify-end space-x-3 pt-6 border-t">
                    {isEditing && (
                      <Button
                        type="button"
                        onClick={() => {
                          setFormData(initialFormState);
                          setIsEditing(false);
                        }}
                        className="px-4 py-2 border border-gray-300 text-gray-700 hover:bg-gray-50 text-base transition-colors duration-200"
                      >
                        Cancel
                      </Button>
                    )}
                    <Button
                      type="submit"
                      disabled={loading}
                      className="px-6 py-2 bg-blue-600 text-white hover:bg-blue-700 text-base font-medium transition-colors duration-200"
                    >
                      {loading ? (
                        <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Processing...
                        </span>
                      ) : (
                        <span>{isEditing ? 'Update Plan' : 'Create Plan'}</span>
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            </Card>

            {/* Subscription Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subscriptions.map((subscription) => (
                <Card 
                  key={subscription.id} 
                  className="relative transform hover:scale-105 transition-all duration-200 hover:shadow-xl bg-white border border-gray-200"
                >
                  <div className="absolute top-4 right-4 flex space-x-2">
                    <button
                      onClick={() => handleEdit(subscription)}
                      className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-full transition-colors duration-200"
                      title="Edit plan"
                    >
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                    </button>
                    <button
                      onClick={() => subscription.id && handleDelete(subscription.id)}
                      className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-full transition-colors duration-200"
                      title="Delete plan"
                    >
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold text-gray-900">{subscription.name}</h3>
                      <span className={`px-3 py-1 rounded-full text-base font-medium ${
                        subscription.is_active 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {subscription.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-4 line-clamp-2 text-base">{subscription.description}</p>
                    <div className="space-y-4 border-t pt-4">
                      <div className="flex justify-between items-center">
                        <span className="text-base font-medium text-gray-500">Price</span>
                        <span className="text-xl font-bold text-blue-600">${subscription.price}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-base font-medium text-gray-500">Duration</span>
                        <span className="text-base text-gray-900">{subscription.duration_days} days</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-base font-medium text-gray-500">Max Exams</span>
                        <span className="text-base text-gray-900">{subscription.max_exams}</span>
                      </div>
                      <div>
                        <span className="text-base font-medium text-gray-500 block mb-2">Features</span>
                        <p className="text-base text-gray-900">{subscription.features}</p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Subscriptions; 