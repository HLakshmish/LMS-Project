import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { MainLayout, AdminSidebar } from '../../components/layout';
import DashboardStats from '../../components/dashboard/DashboardStats';
import RecentActivity from '../../components/dashboard/RecentActivity';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface User {
  id: number;
  username: string;
  email: string;
  role: string;
  created_at: string;
  updated_at: string | null;
}

interface Subscription {
  id: number;
  status: string;
  created_at: string;
  updated_at: string | null;
}

interface DashboardPageProps {
  user: {
    name: string;
    role: string;
    avatar?: string;
  };
  onLogout: () => void;
}

const AdminDashboard: React.FC<DashboardPageProps> = ({ user, onLogout }) => {
  const [userStats, setUserStats] = useState({
    total: 0,
    students: 0,
    teachers: 0,
    admins: 0,
    loading: true,
    error: null as string | null
  });

  const [subscriptionStats, setSubscriptionStats] = useState({
    total: 0,
    active: 0,
    loading: true,
    error: null as string | null
  });

  const getAuthHeaders = () => {
    const token = localStorage.getItem('token');
    return {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
  };

  useEffect(() => {
    const fetchUserStats = async () => {
      try {
        const response = await axios.get<User[]>('http://localhost:8000/api/users/users/', getAuthHeaders());
        const users = response.data;
        
        // Calculate user statistics
        const totalUsers = users.length;
        const teachers = users.filter(user => user.role === 'teacher').length;
        const students = users.filter(user => user.role === 'student').length;
        const admins = users.filter(user => user.role === 'admin').length;

        setUserStats({
          total: totalUsers,
          students: students,
          teachers: teachers,
          admins: admins,
          loading: false,
          error: null
        });
      } catch (error) {
        setUserStats(prev => ({
          ...prev,
          loading: false,
          error: 'Failed to fetch user statistics'
        }));
      }
    };

    const fetchSubscriptionStats = async () => {
      try {
        const response = await axios.get<Subscription[]>('http://localhost:8000/api/subscriptions/subscriptions/', getAuthHeaders());
        const subscriptions = response.data;
        
        // Calculate subscription statistics
        const totalSubscriptions = subscriptions.length;
        const activeSubscriptions = subscriptions.filter(sub => sub.status === 'active').length;

        setSubscriptionStats({
          total: totalSubscriptions,
          active: activeSubscriptions,
          loading: false,
          error: null
        });
      } catch (error) {
        setSubscriptionStats(prev => ({
          ...prev,
          loading: false,
          error: 'Failed to fetch subscription statistics'
        }));
      }
    };

    fetchUserStats();
    fetchSubscriptionStats();
  }, []);

  // Updated stats array using real data
  const stats = [
    {
      title: 'Total Users',
      value: userStats.loading ? '-' : userStats.total,
      icon: (
        <div className="rounded-md bg-blue-500 p-3">
          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
          </svg>
        </div>
      ),
      change: {
        value: '12%',
        isPositive: true,
      },
    },
    {
      title: 'Active Subscriptions',
      value: subscriptionStats.loading ? '-' : subscriptionStats.active,
      icon: (
        <div className="rounded-md bg-green-500 p-3">
          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
          </svg>
        </div>
      ),
      change: {
        value: '8%',
        isPositive: true,
      },
    },
    {
      title: 'Exam Statistics',
      value: '72%',
      icon: (
        <div className="rounded-md bg-purple-500 p-3">
          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
        </div>
      ),
      change: {
        value: '3%',
        isPositive: true,
      },
    },
    {
      title: 'Content Metrics',
      value: 2156,
      icon: (
        <div className="rounded-md bg-amber-500 p-3">
          <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
        </div>
      ),
      change: {
        value: '15%',
        isPositive: true,
      },
    },
  ];

  const activities = [
    {
      id: '1',
      type: 'system' as const,
      title: 'System Update',
      description: 'Completed',
      timestamp: '2 hours ago',
    },
    {
      id: '2',
      type: 'system' as const,
      title: 'New Teacher Registration',
      description: 'User Sarah Johnson completed',
      timestamp: '1 day ago',
      link: '/users/456',
    },
    {
      id: '3',
      type: 'subscription' as const,
      title: 'Premium Plan',
      description: 'User Michael Brown purchased',
      timestamp: '3 days ago',
      link: '/subscriptions/789',
    },
    {
      id: '4',
      type: 'exam' as const,
      title: 'Mathematics Final',
      description: 'Teacher John Smith created',
      timestamp: '1 week ago',
      link: '/exams/101',
    },
  ];

  // Updated userRoleDistribution using real data
  const userRoleDistribution = [
    { role: 'Students', count: userStats.students, color: 'bg-blue-500' },
    { role: 'Teachers', count: userStats.teachers, color: 'bg-green-500' },
    { role: 'Admins', count: userStats.admins, color: 'bg-purple-500' },
  ];

  const quickActions = [
    {
      title: 'Manage Users',
      icon: (
        <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      ),
      link: '/admin/users',
      color: 'bg-blue-100 text-blue-700',
    },
    {
      title: 'Manage Courses',
      icon: (
        <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path d="M12 14l9-5-9-5-9 5 9 5z" />
          <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998a12.078 12.078 0 01.665-6.479L12 14z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998a12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" />
        </svg>
      ),
      link: '/admin/courses',
      color: 'bg-green-100 text-green-700',
    },
    {
      title: 'Manage Subscriptions',
      icon: (
        <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
        </svg>
      ),
      link: '/admin/subscriptions',
      color: 'bg-purple-100 text-purple-700',
    },
    {
      title: 'System Settings',
      icon: (
        <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
      link: '/settings',
      color: 'bg-amber-100 text-amber-700',
    },
  ];

  return (
    <MainLayout user={user} onLogout={onLogout} sidebarContent={<AdminSidebar />}>
      <div className="h-screen bg-gray-50 overflow-hidden flex flex-col">
        {/* Header Section */}
        <div className="bg-blue-600 text-white py-6 px-8 flex-none">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-2xl font-bold mb-2">Welcome back, {user.name}!</h1>
            <p className="text-blue-100">Here's what's happening with your system.</p>
            {userStats.error && (
              <div className="mt-2 text-sm bg-red-50 text-red-600 p-2 rounded-md">
                {userStats.error}
              </div>
            )}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-auto px-8 py-6">
          <div className="max-w-7xl mx-auto">
            <DashboardStats stats={stats} />

            <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
              {quickActions.map((action, index) => (
                <Link key={index} to={action.link}>
                  <Card className="h-full hover:shadow-md transition-shadow duration-200">
                    <div className="p-4 flex flex-col items-center text-center">
                      <div className={`rounded-full p-3 mb-4 ${
                        action.title === 'Manage Users' ? 'bg-blue-100 text-blue-700' :
                        action.title === 'Manage Courses' ? 'bg-blue-100 text-blue-700' :
                        action.title === 'Manage Subscriptions' ? 'bg-blue-100 text-blue-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {action.icon}
                      </div>
                      <h3 className="text-lg font-medium text-gray-900">{action.title}</h3>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <RecentActivity activities={activities} />
              </div>
              <div>
                <Card title="User Distribution">
                  <div className="space-y-4">
                    {userRoleDistribution.map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-700">{item.role}</span>
                          <span className="text-sm text-gray-500">{item.count}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div 
                            className="bg-blue-500 h-2.5 rounded-full"
                            style={{ width: `${(item.count / userRoleDistribution.reduce((acc, curr) => acc + curr.count, 0)) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}           
                  </div>
                  <div className="mt-6">
                    <Link to="/admin/users">
                      <Button variant="light" fullWidth className="text-blue-600 hover:bg-blue-50">
                        View all users
                      </Button>
                    </Link>
                  </div>
                </Card>

                <Card title="System Status" className="mt-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-700">Server Status</span>
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">Operational</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-700">Database Status</span>
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">Operational</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-700">Storage Usage</span>
                      <span className="text-sm text-gray-500">68%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: '68%' }}></div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-700">Memory Usage</span>
                      <span className="text-sm text-gray-500">42%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: '42%' }}></div>
                    </div>
                  </div>
                  <div className="mt-6">
                    <Link to="/system/status">
                      <Button variant="light" fullWidth className="text-blue-600 hover:bg-blue-50">
                        View detailed status
                      </Button>
                    </Link>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default AdminDashboard;
